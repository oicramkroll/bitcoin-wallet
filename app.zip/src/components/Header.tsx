
import Menu from './Menu';

export default function Header() {
    return (
        <>
            <Menu />
        </>
    );
}
