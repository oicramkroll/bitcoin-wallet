import { useEffect, useState } from 'react';
import { auth, db } from '../firebase-config';
import {
  collection,
  addDoc,
  onSnapshot,
  deleteDoc,
  doc
} from 'firebase/firestore';
import { showToast } from '../toast';
import Layout from '../components/Layout';
import { useLoading } from '../context/LoadingContext';

export default function Wallets() {
  const [address, setAddress] = useState('');
  const [wallets, setWallets] = useState<{ id: string; address: string }[]>([]);
  const { setLoading } = useLoading();

  useEffect(() => {
    const ref = collection(db, 'wallets', auth.currentUser!.uid, 'addresses');
    const unsubscribe = onSnapshot(ref, (snapshot) => {
      const data = snapshot.docs.map((doc) => ({
        id: doc.id,
        address: doc.data().address
      }));
      setWallets(data);
    }, (error) => {
      console.error(error);
      showToast('Erro ao carregar carteiras', true);
    });

    return unsubscribe;
  }, []);

  const addWallet = async () => {
    if (!address) return;
    try {
      setLoading(true);
      const ref = collection(db, 'wallets', auth.currentUser!.uid, 'addresses');
      await addDoc(ref, { address });
      setAddress('');
      showToast('Endereço adicionado!');
    } catch (err) {
      console.error(err);
      showToast('Erro ao adicionar endereço', true);
    } finally {
      setLoading(false);
    }
  };

  const removeWallet = async (id: string) => {
    try {
      setLoading(true);
      await deleteDoc(doc(db, 'wallets', auth.currentUser!.uid, 'addresses', id));
      showToast('Endereço removido!');
    } catch (err) {
      console.error(err);
      showToast('Erro ao remover endereço', true);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Layout>
      <h2>Carteiras BTC</h2>
      <input
        value={address}
        onChange={(e) => setAddress(e.target.value)}
        placeholder="Endereço Bitcoin"
      />
      <button onClick={addWallet}>Adicionar</button>

      <ul>
        {wallets.map((w) => (
          <li key={w.id}>
            {w.address}
            <button onClick={() => removeWallet(w.id)}>Remover</button>
          </li>
        ))}
      </ul>
    </Layout>
  );
}
